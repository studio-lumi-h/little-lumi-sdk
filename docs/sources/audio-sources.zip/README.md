# 음성 디코더 원본과 수정 소스

JavaSound용 라이브러리입니다. 바이너리와 원본은 Maven Central에서 받은 그대로이며 소스 JAR는 런타임 클래스패스에 넣지 않습니다. LGPL-2.0-or-later 구성 요소는 LGPL-2.1 조건으로 배포합니다. 라이브러리 수정·교체 및 이를 위한 역공학을 허용합니다. 라이선스 본문은 LGPL-2.1.txt, 각 파일의 저작권은 소스 JAR에 보존합니다.

VorbisSPI의 짧은 파일·마지막 페이지 버퍼 처리 수정은 앱 JAR에 주입됩니다. 수정본 전체는 DecodedVorbisAudioInputStream.java이며 upstream과 같은 LGPL 조건입니다. `javac -cp "lib/*" -d classes DecodedVorbisAudioInputStream.java`로 컴파일한 뒤 앱 JAR의 같은 클래스를 교체할 수 있습니다.

| 파일 | Maven Central 원본 | SHA-256 |
|---|---|---|
| vorbisspi-1.0.3.3.jar | https://repo.maven.apache.org/maven2/com/googlecode/soundlibs/vorbisspi/1.0.3.3/vorbisspi-1.0.3.3.jar | `72a0d82d606773fbcaffc835c2e817066a6c45de722795d42e5506510bfa794e` |
| vorbisspi-1.0.3.3-sources.jar | https://repo.maven.apache.org/maven2/com/googlecode/soundlibs/vorbisspi/1.0.3.3/vorbisspi-1.0.3.3-sources.jar | `bb31109bd8953a286f2ba18b36085f247f520e0392b532d36b840622ac9c757b` |
| jorbis-0.0.17.4.jar | https://repo.maven.apache.org/maven2/com/googlecode/soundlibs/jorbis/0.0.17.4/jorbis-0.0.17.4.jar | `92508c4ad6af76c2e86052844b958f950fe72579bbb53edd0fda0f16a4c40227` |
| jorbis-0.0.17.4-sources.jar | https://repo.maven.apache.org/maven2/com/googlecode/soundlibs/jorbis/0.0.17.4/jorbis-0.0.17.4-sources.jar | `bdfc2237ac3fe7f24207569170b4733eb3bf12b31294d6950d2c3b155a8bc1e5` |
| mp3spi-1.9.5.4.jar | https://repo.maven.apache.org/maven2/com/googlecode/soundlibs/mp3spi/1.9.5.4/mp3spi-1.9.5.4.jar | `f2bd4d0b63532b52eaf9c086528ed8379e5a8805af759c4dbdea5b7a40e4e87e` |
| mp3spi-1.9.5.4-sources.jar | https://repo.maven.apache.org/maven2/com/googlecode/soundlibs/mp3spi/1.9.5.4/mp3spi-1.9.5.4-sources.jar | `8609ca1910eb46147a99e574239f3d09161aaae1c7177d70e1024176e57b4f6a` |
| jlayer-1.0.1.4.jar | https://repo.maven.apache.org/maven2/com/googlecode/soundlibs/jlayer/1.0.1.4/jlayer-1.0.1.4.jar | `863a51470ab4d581c6269dcd5a0471a226932ec5b2ef3f79fe86ab559387ac5c` |
| jlayer-1.0.1.4-sources.jar | https://repo.maven.apache.org/maven2/com/googlecode/soundlibs/jlayer/1.0.1.4/jlayer-1.0.1.4-sources.jar | `a02f1ff01ade473e5fd97810154838241f6e3930eafee414673bb474ae6969a2` |
| jflac-codec-1.5.2.jar | https://repo.maven.apache.org/maven2/org/jflac/jflac-codec/1.5.2/jflac-codec-1.5.2.jar | `36bec99e9d159cdd7419d4c27551697600cb8d65a523dca008b2f8574ff97a0c` |
| jflac-codec-1.5.2-sources.jar | https://repo.maven.apache.org/maven2/org/jflac/jflac-codec/1.5.2/jflac-codec-1.5.2-sources.jar | `4e4ca0e0c2b7eb3e18112fed2534c3b0a0d702455f6fae51ae47eccbc6b31b51` |
| tritonus-share-0.3.7.4.jar | https://repo.maven.apache.org/maven2/com/googlecode/soundlibs/tritonus-share/0.3.7.4/tritonus-share-0.3.7.4.jar | `6f626b41dc72074656059de1a25bc6f1c5abb202b57d37c538f5714f54efdab4` |
| tritonus-share-0.3.7.4-sources.jar | https://repo.maven.apache.org/maven2/com/googlecode/soundlibs/tritonus-share/0.3.7.4/tritonus-share-0.3.7.4-sources.jar | `54ddf95a25cb4555365501b5994a8a548cecf758dcced80d07a4f4c68d79cda9` |
