#!/usr/bin/env python3
"""Recombine an unsigned Little LUMI app JAR with your compiled hqx classes.

python relink_hqx.py --input Shimeji-ee.jar --classes my-classes --out modified.jar
The input and any existing output are never overwritten. Only hqx/*.class changes.
"""
import argparse
from pathlib import Path
import zipfile


REQUIRED = {'hqx/' + name + '.class' for name in ('Hq2x', 'Hq3x', 'Hq4x', 'Util')}


def recombine(input_jar, classes, output):
    input_jar, classes, output = Path(input_jar), Path(classes), Path(output)
    if input_jar.resolve() == output.resolve() or output.exists():
        raise ValueError('Output must be a new file, separate from the input JAR.')
    replacements = {}
    for file in sorted((classes / 'hqx').rglob('*.class')):
        if file.is_symlink() or not file.resolve().is_relative_to(classes.resolve()):
            raise ValueError('Replacement classes must be regular files inside the classes directory.')
        data = file.read_bytes()
        if not data.startswith(b'\xca\xfe\xba\xbe'):
            raise ValueError(f'Invalid class file: {file}')
        replacements[file.relative_to(classes).as_posix()] = data
    if not REQUIRED <= replacements.keys():
        raise ValueError('Compile all four hqx sources first (Hq2x, Hq3x, Hq4x, Util).')
    with zipfile.ZipFile(input_jar) as source:
        names = source.namelist()
        if len(names) != len(set(names)) or not REQUIRED <= set(names):
            raise ValueError('Expected one copy of each hqx class in the input JAR.')
        if any(n.upper().startswith('META-INF/') and n.upper().endswith(('.SF', '.RSA', '.DSA', '.EC')) for n in names):
            raise ValueError('Signed JAR: obtain an unsigned recombinable app build first.')
        # Exclusive creation also protects a file created after the initial check.
        with output.open('xb') as stream:
            try:
                with zipfile.ZipFile(stream, 'w', zipfile.ZIP_DEFLATED) as target:
                    target.comment = source.comment
                    for entry in source.infolist():
                        if entry.filename.startswith('hqx/') and entry.filename.endswith('.class'):
                            continue
                        target.writestr(entry, source.read(entry.filename))
                    for name, data in replacements.items():
                        target.writestr(name, data)
            except Exception:
                stream.close()
                output.unlink()
                raise
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', required=True, type=Path)
    parser.add_argument('--classes', required=True, type=Path)
    parser.add_argument('--out', required=True, type=Path)
    args = parser.parse_args()
    try:
        output = recombine(args.input, args.classes, args.out)
    except (ValueError, OSError, zipfile.BadZipFile) as error:
        parser.error(str(error))
    print(f'Recombined: {output}. Keep the source, notices and original app JAR.')


if __name__ == '__main__':
    main()
