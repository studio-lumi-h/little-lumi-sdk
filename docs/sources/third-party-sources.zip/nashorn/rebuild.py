#!/usr/bin/env python3
# SPDX-License-Identifier: BSD-3-Clause
# Copyright (c) 2026 STUDIO LUMI. See ../HELPER-LICENSE.txt.
"""Rebuild the pinned Nashorn sources + host-access patch offline (JDK 11+, Git).

Uses the app's existing ASM dependencies. All intermediate files live in an OS
temporary directory. No downloaded tools, binary rewriting, or source overlays.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import zipfile


HERE = Path(__file__).resolve().parent


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rebuild(output, lib, javac="javac", java="java"):
    manifest = json.loads((HERE.parent / "sources.json").read_text(encoding="utf-8"))["nashorn"]
    archive = HERE.parent / manifest["archive"]
    patch = HERE / "classfilter-host-access.patch"
    for path, expected in ((archive, manifest["archive_sha256"]),
                           (patch, manifest["patch_sha256"])):
        if sha256(path) != expected:
            raise ValueError(f"Pinned source differs: {path}")
    dependencies = sorted(lib.glob("asm*-7.3.1.jar"))
    if len(dependencies) != 5:
        raise ValueError("Expected the five ASM 7.3.1 JARs shipped with Little LUMI")
    cp = os.pathsep.join(str(p.resolve()) for p in dependencies)
    with tempfile.TemporaryDirectory(prefix="lumi-nashorn-build-") as temporary:
        work = Path(temporary)
        with zipfile.ZipFile(archive) as source:
            source.extractall(work)
        root = work / ("nashorn-" + manifest["revision"])
        subprocess.run(["git", "apply", "--no-index", str(patch)], cwd=root, check=True)
        sources = root / "src/org.openjdk.nashorn/share/classes"
        classes, nasgen = work / "classes", work / "nasgen"
        classes.mkdir()
        nasgen.mkdir()

        def compile_java(paths, destination, classpath):
            args = work / (destination.name + ".args")
            args.write_text("\n".join('"' + str(p).replace("\\", "/") + '"'
                                      for p in sorted(paths)), encoding="utf-8")
            subprocess.run([javac, "--release", "11", "-encoding", "UTF-8", "-g",
                            "-parameters", "-cp", classpath, "-d", str(destination),
                            "@" + str(args)], check=True)

        # module-info must be compiled on the module path, as in upstream's Ant build.
        args = work / "engine.args"
        args.write_text("\n".join('"' + str(p).replace("\\", "/") + '"'
                                  for p in sorted(sources.rglob("*.java"))), encoding="utf-8")
        subprocess.run([javac, "--release", "11", "-encoding", "UTF-8", "-g",
                        "-parameters", "--module-path", cp, "-d", str(classes),
                        "@" + str(args)], check=True)
        compile_java((root / "make/nashorn/buildtools/nasgen/src").rglob("*.java"),
                     nasgen, str(classes) + os.pathsep + cp)
        subprocess.run([java, "-cp", os.pathsep.join((str(nasgen), str(classes), cp)),
                        "org.openjdk.nashorn.internal.tools.nasgen.Main", str(classes),
                        "org.openjdk.nashorn.internal.objects", str(classes)], check=True)
        for folder in ("api/scripting/resources", "internal/runtime/resources", "tools/resources"):
            relative = Path("org/openjdk/nashorn") / folder
            shutil.copytree(sources / relative, classes / relative, dirs_exist_ok=True)
        anchor = Path("org/openjdk/nashorn/internal/codegen/anchor.properties")
        shutil.copyfile(sources / anchor, classes / anchor)
        (classes / "org/openjdk/nashorn/internal/runtime/resources/version.properties").write_text(
            "version_string=15.7-lumi.2\nversion_short=15.7-lumi.2\n", encoding="utf-8")
        services = classes / "META-INF/services"
        services.mkdir(parents=True, exist_ok=True)
        for name, provider in {
            "javax.script.ScriptEngineFactory": "org.openjdk.nashorn.api.scripting.NashornScriptEngineFactory",
            "jdk.dynalink.linker.GuardingDynamicLinkerExporter": "org.openjdk.nashorn.api.linker.NashornLinkerExporter",
        }.items():
            (services / name).write_text(provider + "\n", encoding="utf-8")
        (classes / "META-INF/MANIFEST.MF").write_bytes(
            b"Manifest-Version: 1.0\r\n\r\nName: org/openjdk/nashorn/\r\n"
            b"Implementation-Title: OpenJDK Nashorn (Little LUMI host-access patch)\r\n"
            b"Implementation-Version: 15.7-lumi.2\r\n\r\n")
        output.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as jar:
            for path in sorted(classes.rglob("*")):
                if path.is_file():
                    entry = zipfile.ZipInfo(path.relative_to(classes).as_posix(), (2026, 10, 12, 0, 0, 0))
                    entry.compress_type = zipfile.ZIP_DEFLATED
                    entry.external_attr = 0o100644 << 16
                    jar.writestr(entry, path.read_bytes())
    print(f"Built {output}: sha256={sha256(output)}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--lib", type=Path, required=True)
    parser.add_argument("--javac", default="javac")
    parser.add_argument("--java", default="java")
    args = parser.parse_args()
    rebuild(args.output.resolve(), args.lib.resolve(), args.javac, args.java)
